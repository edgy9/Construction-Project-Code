simple-websocket
================

[![Build status](https://github.com/miguelgrinberg/simple-websocket/workflows/build/badge.svg)](https://github.com/miguelgrinberg/simple-websocket/actions) [![codecov](https://codecov.io/gh/miguelgrinberg/simple-websocket/branch/main/graph/badge.svg)](https://codecov.io/gh/miguelgrinberg/simple-websocket)

Simple WebSocket server and client for Python.

## Resources

- [Documentation](http://simple-websocket.readthedocs.io/en/latest/)
- [PyPI](https://pypi.python.org/pypi/simple-websocket)
- [Change Log](https://github.com/miguelgrinberg/simple-websocket/blob/main/CHANGES.md)

