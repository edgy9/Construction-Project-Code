from engineio.async_drivers import sanic as async_sanic  # noqa: F401
