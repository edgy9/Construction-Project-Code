#!/bin/bash
python text_packet.py
python binary_packet.py
python binary_b64_packet.py
python json_packet.py
python payload.py
python server_receive.py
