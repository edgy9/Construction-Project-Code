.. python-socketio documentation master file, created by
   sphinx-quickstart on Sun Nov 25 11:52:38 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python-socketio
===============

This projects implements Socket.IO clients and servers that can run standalone
or integrated with a variety of Python web frameworks.

.. toctree::
   :maxdepth: 3

   intro
   client
   server
   api

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
